import os
import datetime
import socket
import websocket
import json
import ssl
import time
import base64
import hashlib
import hmac
import requests
import azure.functions as func
import logging
import certifi
import re

from .sentinel_connector import AzureSentinelConnector

customer_id = os.environ['WorkspaceID'] 
shared_key = os.environ['WorkspaceKey']
cluster_id = os.environ['ProofpointClusterID']
_token = os.environ['ProofpointTokenNew']
time_delay_minutes = 60
event_types = ["message"]
logAnalyticsUri = os.environ.get('logAnalyticsUri')

if ((logAnalyticsUri in (None, '') or str(logAnalyticsUri).isspace())):    
    logAnalyticsUri = 'https://' + customer_id + '.ods.opinsights.azure.com'

pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern,str(logAnalyticsUri))
if(not match):
    raise Exception("ProofpointPOD: Invalid Log Analytics Uri.")

def main(mytimer2: func.TimerRequest) -> None:
    if mytimer2.past_due:
        logging.info('The timer is past due!')

    logging.info('Starting program')
    if datetime.datetime.utcnow().minute < 2:
        time.sleep(120)
    api = Proofpoint_api()
    for evt_type in event_types:
        api.get_data(event_type=evt_type)

class Proofpoint_api:
    def __init__(self):
        self.cluster_id = cluster_id
        self.logAnalyticsUri = logAnalyticsUri
        self._token = _token
        self.time_delay_minutes = int(time_delay_minutes)
        self.gen_timeframe(time_delay_minutes=self.time_delay_minutes)

    def gen_timeframe(self, time_delay_minutes):
        before_time = datetime.datetime.utcnow() - datetime.timedelta(minutes=time_delay_minutes)
        self.before_time = before_time.strftime("%Y-%m-%dT%H:59:59+0000")
        self.after_time = before_time.strftime("%Y-%m-%dT%H:00:00+0000")

    def set_websocket_conn(self, event_type):
        max_retries = 3
        for attempt in range(max_retries):
        url = f"wss://logstream.proofpoint.com:443/v1/stream?cid={self.cluster_id}&type={event_type}"
        logging.info('Opening Websocket logstream {}'.format(url))
        # defining headers for websocket connection (do not change this)
        header = {
            "Host": "logstream.proofpoint.com:443",
            "Connection": "Upgrade",
            "Upgrade": "websocket",
            "Authorization": f"Bearer {self._token}",
            "Sec-WebSocket-Key": "SGVsbG8sIHdvcmxkIQ==",
            "Sec-WebSocket-Version": "13"
        }
        sslopt = {
            'cert_reqs': ssl.CERT_REQUIRED,
            'ca_certs': certifi.where(),
            'check_hostname': True
        }
        try:
            ws = websocket.create_connection(url, header=header, sslopt=sslopt)
            ws.settimeout(20)
            time.sleep(2)
            logging.info(
                'Websocket connection established to cluster_id={}, event_type={}'.format(self.cluster_id, event_type))
            print(
                'Websocket connection established to cluster_id={}, event_type={}'.format(self.cluster_id, event_type))
            return ws
        except Exception as err:
            logging.error('Error while connectiong to websocket {}'.format(err))
            print('Error while connectiong to websocket {}'.format(err))
            if attempt < max_retries - 1:
                logging.info('Retrying connection in 5 seconds...')
                time.sleep(5)  # Wait for a while before retrying
            else:
                return None
    def get_data(self, event_type=None):
        sent_events = 0
        ws = self.set_websocket_conn(event_type)
        time.sleep(2)
        if ws is not None:
            events = []
            try:
                time.sleep(300)
                ws.close()
            except Exception as err:
                logging.error('Error while closing socket: {}'.format(err))
                print('Error while closing socket: {}'.format(err))                
        logging.info('Total events sent: {}. Type: {}. Period(UTC): {} - {}'.format(sent_events, event_type,
                                                                                            self.after_time,
                                                                                            self.before_time))
        print('Total events sent: {}. Type: {}. Period(UTC): {} - {}'.format(sent_events, event_type,
                                                                                            self.after_time,
                                                                                           self.before_time))